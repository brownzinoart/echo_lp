# Hedgehox + Echo Landing Page – Design System

## 1. Brand Voice & Visual Tone

- **Tone:** Professional, minimal, tech-forward with a biotech/pharma emphasis  
- **Imagery Style:** Clean grid, futuristic networks, soft gradients, and literal brand elements (hedgehog mascot)
- **Microcopy:** Conversational yet purposeful (e.g., "Hold up! What's with the hedgehogs?")

## 2. Layout & Spacing

| Element           | Specs                                      |
|------------------|--------------------------------------------|
| Page Max Width    | 1280px (centered, responsive padding)       |
| Grid System       | 12-column grid w/ 24px gutters              |
| Section Spacing   | 80px top/bottom desktop, 40px mobile        |
| Content Padding   | 32px sides (mobile), 80px desktop           |

## 3. Typography

| Style        | Font               | Weight | Size    | Line Height | Use For               |
|--------------|--------------------|--------|---------|-------------|------------------------|
| Headline XL  | Inter / sans-serif | 700    | 48px    | 1.2         | Hero heading           |
| Headline SM  | Inter / sans-serif | 600    | 32px    | 1.25        | Section headings       |
| Body Text    | Inter / sans-serif | 400    | 16–18px | 1.6         | Paragraphs             |
| Button Label | Inter / sans-serif | 600    | 14px    | 1.3         | Buttons, links         |

> Use `Inter` or system font fallback. Slight letter spacing (0.2px) for uppercase.

## 4. Colors

| Name           | Hex       | Usage                                |
|----------------|-----------|---------------------------------------|
| Primary Navy   | #1A1D29   | Header, footer, CTA buttons           |
| Accent Yellow  | #FFD23F   | Highlights, underline in hero text    |
| Soft Gray      | #F5F7FA   | Backgrounds, cards                    |
| Light Blue     | #D9ECF2   | Network background elements           |
| Text Dark      | #121212   | Primary body text                     |
| Text Light     | #4F4F4F   | Subheadings and muted text            |

## 5. Components

### Navbar
- Left-aligned logo
- Right-aligned nav links with hover underline
- CTA button “Contact us” in header: small pill button

### Hero Section
- Two-column layout:
  - Left: headline + paragraph + CTA
  - Right: mascot or product screenshot
- Yellow underline spans key words
- CTA Button: `Learn how we can help →`

### Zigzag Benefits Section
- Alternating image + text layout
- Three tiles minimum
- Each includes:
  - Heading (bold)
  - Paragraph
  - Optional CTA

### About / Team Section
- Bio card-style: image/avatar left, description right
- 2-column on desktop, stacked on mobile

### Newsletter / CTA Section
- Light background
- Bold heading
- Email input + submit button inline (desktop)

### Footer
- Minimal: logo left, nav center, links right
- Subtle line separator
- Text: © Year Hedgehox. All rights reserved.

## 6. Imagery Guidelines

- Use transparent PNG or soft shadow for mascot
- Backgrounds: abstract neural/fiber visuals, soft blur
- Screenshot styling: rounded corners (12px), UI-style framing

## 7. Implementation Notes

- Use **Tailwind CSS** or utility-first classes
- Build as modular components: `HeroSection`, `Footer`, etc.
- Use `scroll-mt-[offset]` for smooth anchor scrolling
- Mobile-first responsive strategy